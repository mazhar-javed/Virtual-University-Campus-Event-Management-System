<?php
session_start();
include '../config/config.php';

// Only admin access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit;
}

// Messages
$message = "";

// ===== Add User =====
if(isset($_POST['add_user'])){
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // Email check
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        $message = "Email already exists!";
    } else {
        $hashed_password = MD5($password);
        mysqli_query($conn, "INSERT INTO users (full_name,email,password,role) VALUES ('$full_name','$email','$hashed_password','$role')");
        $message = "User added successfully!";
    }
}

// ===== Delete User =====
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM users WHERE id='$id'");
    $message = "User deleted successfully!";
}

// ===== Edit User =====
if(isset($_POST['edit_user'])){
    $id = intval($_POST['id']);
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    if(!empty($password)){
        $hashed_password = MD5($password);
        $update_query = "UPDATE users SET full_name='$full_name', email='$email', password='$hashed_password', role='$role' WHERE id='$id'";
    } else {
        $update_query = "UPDATE users SET full_name='$full_name', email='$email', role='$role' WHERE id='$id'";
    }

    mysqli_query($conn, $update_query);
    $message = "User updated successfully!";
}

// Fetch all non-admin users
$users = mysqli_query($conn, "SELECT * FROM users WHERE role != 'admin' ORDER BY id DESC");

// Check if edit mode
$edit_user = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $edit_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id='$id' AND role != 'admin'"));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users - Admin - VUCEMS</title>
<style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f8f9fa;
    min-height: 100vh;
    padding: 30px;
}

/* ===========================
   2. MAIN CONTENT / CONTAINER
=========================== */
.container {
    max-width: 800px;
    margin: auto;
}

h1 {
    color: #004080;
    margin-bottom: 20px;
}

p {
    color: red;
    font-weight: bold;
    margin-bottom: 15px;
}

/* ===========================
   3. FORM
=========================== */
form {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 15px;
}

form label {
    font-weight: bold;
}

form input[type="text"],
form input[type="email"],
form input[type="password"],
form select {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 100%;
}

form input[type="submit"],
.back-btn {
    padding: 12px;
    background: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    text-align: center;
}

form input[type="submit"]:hover,
.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   4. USERS TABLE
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

table th,
table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    font-size: 14px;
}

table th {
    background: #004080;
    color: #fff;
}

table tr:hover {
    background: #f1f1f1;
}

/* Action buttons */
.action-btn {
    padding: 5px 10px;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
    font-size: 13px;
}

.edit-btn {
    background: #28a745;
}

.edit-btn:hover {
    background: #218838;
}

.delete-btn {
    background: #dc3545;
}

.delete-btn:hover {
    background: #c82333;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    color: #666;
    margin-top: 20px;
}

/* ===========================
   6. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    table,
    form {
        font-size: 12px;
    }
}

</style>
</head>
<body>

<div class="container">
<h1>Manage Users</h1>

<?php if($message != ""): ?>
<p><?php echo $message; ?></p>
<?php endif; ?>

<!-- Add / Edit Form -->
<form method="post" action="">
    <input type="hidden" name="id" value="<?php echo $edit_user ? $edit_user['id'] : ''; ?>">

    <label>Full Name</label>
    <input type="text" name="full_name" value="<?php echo $edit_user ? $edit_user['full_name'] : ''; ?>" required>

    <label>Email</label>
    <input type="email" name="email" value="<?php echo $edit_user ? $edit_user['email'] : ''; ?>" required>

    <label>Password <?php echo $edit_user ? '(leave blank to keep unchanged)' : ''; ?></label>
    <input type="password" name="password">

    <label>Role</label>
    <select name="role" required>
        <option value="student" <?php if($edit_user && $edit_user['role']=='student') echo 'selected'; ?>>Student</option>
        <option value="organizer" <?php if($edit_user && $edit_user['role']=='organizer') echo 'selected'; ?>>Organizer</option>
    </select>

    <input type="submit" name="<?php echo $edit_user ? 'edit_user' : 'add_user'; ?>" value="<?php echo $edit_user ? 'Update User' : 'Add User'; ?>">
    <?php if($edit_user): ?>
        <a href="manage_users.php" class="back-btn" style="display:block; margin-top:10px;">Cancel Edit</a>
    <?php endif; ?>
</form>

<!-- Back to Dashboard Button -->
<a href="dashboard.php" class="back-btn" style="display:block; margin-bottom:20px;">&larr; Back to Dashboard</a>

<!-- Users Table -->
<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Role</th>
        <th>Actions</th>
    </tr>
    <?php while($user = mysqli_fetch_assoc($users)): ?>
    <tr>
        <td><?php echo $user['id']; ?></td>
        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
        <td><?php echo htmlspecialchars($user['email']); ?></td>
        <td><?php echo $user['role']; ?></td>
        <td>
            <a class="action-btn edit-btn" href="?edit=<?php echo $user['id']; ?>">Edit</a>
            <a class="action-btn delete-btn" href="?delete=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

</div>

<footer>
&copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

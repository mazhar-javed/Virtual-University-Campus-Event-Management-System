<?php
session_start();
include '../config/config.php';

// Only admin access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit;
}

// Fetch stats
$total_students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM users WHERE role='student'"))['count'];
$total_organizers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM users WHERE role='organizer'"))['count'];
$total_events = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM events"))['count'];
$total_categories = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM categories"))['count'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Analytics - Admin - VUCEMS</title>
<style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f8f9fa;
    min-height: 100vh;
    padding: 30px;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    max-width: 900px;
    margin: auto;
}

h1 {
    color: #004080;
    margin-bottom: 30px;
}

/* ===========================
   3. CARDS
=========================== */
.cards {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    flex: 1 1 calc(50% - 20px);
    background: #fff;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.card h2 {
    font-size: 40px;
    color: #004080;
    margin-bottom: 10px;
}

.card p {
    font-size: 16px;
    color: #333;
}

/* ===========================
   4. BACK BUTTON
=========================== */
.back-btn {
    padding: 12px 20px;
    background: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    font-size: 16px;
    display: inline-block;
    margin-bottom: 20px;
}

.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    color: #666;
    margin-top: 20px;
}

/* ===========================
   6. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    .card {
        flex: 1 1 100%;
    }
}

</style>
</head>
<body>

<div class="container">
<h1>System Analytics</h1>

<!-- Back to Dashboard -->
<a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

<!-- Cards -->
<div class="cards">
    <div class="card">
        <h2><?php echo $total_students; ?></h2>
        <p>Total Students</p>
    </div>
    <div class="card">
        <h2><?php echo $total_organizers; ?></h2>
        <p>Total Organizers</p>
    </div>
    <div class="card">
        <h2><?php echo $total_events; ?></h2>
        <p>Total Events</p>
    </div>
    <div class="card">
        <h2><?php echo $total_categories; ?></h2>
        <p>Total Categories</p>
    </div>
</div>

</div>

<footer>
&copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

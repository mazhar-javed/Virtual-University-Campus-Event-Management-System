<?php
session_start();
include '../config/config.php';

// Only admin access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit;
}

$message = "";

// ===== Add Category =====
if(isset($_POST['add_category'])){
    $name = mysqli_real_escape_string($conn, $_POST['name']);

    // Check if category exists
    $check = mysqli_query($conn, "SELECT * FROM categories WHERE name='$name'");
    if(mysqli_num_rows($check) > 0){
        $message = "Category already exists!";
    } else {
        mysqli_query($conn, "INSERT INTO categories (name) VALUES ('$name')");
        $message = "Category added successfully!";
    }
}

// ===== Delete Category =====
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM categories WHERE id='$id'");
    $message = "Category deleted successfully!";
}

// ===== Edit Category =====
if(isset($_POST['edit_category'])){
    $id = intval($_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    mysqli_query($conn, "UPDATE categories SET name='$name' WHERE id='$id'");
    $message = "Category updated successfully!";
}

// Fetch all categories
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY id DESC");

// Check if edit mode
$edit_category = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $edit_category = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM categories WHERE id='$id'"));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Categories - Admin - VUCEMS</title>
<style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f8f9fa;
    min-height: 100vh;
    padding: 30px;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    max-width: 600px;
    margin: auto;
}

h1 {
    color: #004080;
    margin-bottom: 20px;
}

p {
    color: red;
    font-weight: bold;
    margin-bottom: 15px;
}

/* ===========================
   3. FORM
=========================== */
form {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 20px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 15px;
}

form label {
    font-weight: bold;
}

form input[type="text"] {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 100%;
    font-size: 14px;
}

form input[type="submit"],
.back-btn {
    padding: 12px;
    background: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    text-align: center;
}

form input[type="submit"]:hover,
.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   4. CATEGORIES TABLE
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

table th,
table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    font-size: 14px;
}

table th {
    background: #004080;
    color: #fff;
}

table tr:hover {
    background: #f1f1f1;
}

/* Action buttons */
.action-btn {
    padding: 5px 10px;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    text-decoration: none;
    font-size: 13px;
}

.edit-btn {
    background: #28a745;
}

.edit-btn:hover {
    background: #218838;
}

.delete-btn {
    background: #dc3545;
}

.delete-btn:hover {
    background: #c82333;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    color: #666;
    margin-top: 20px;
}

/* ===========================
   6. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    table,
    form {
        font-size: 12px;
    }
}

</style>
</head>
<body>

<div class="container">
<h1>Manage Categories</h1>

<?php if($message != ""): ?>
<p><?php echo $message; ?></p>
<?php endif; ?>

<!-- Add / Edit Form -->
<form method="post" action="">
    <input type="hidden" name="id" value="<?php echo $edit_category ? $edit_category['id'] : ''; ?>">

    <label>Category Name</label>
    <input type="text" name="name" value="<?php echo $edit_category ? $edit_category['name'] : ''; ?>" required>

    <input type="submit" name="<?php echo $edit_category ? 'edit_category' : 'add_category'; ?>" value="<?php echo $edit_category ? 'Update Category' : 'Add Category'; ?>">
    <?php if($edit_category): ?>
        <a href="manage_categories.php" class="back-btn" style="display:block; margin-top:10px;">Cancel Edit</a>
    <?php endif; ?>
</form>

<!-- Back to Dashboard Button -->
<a href="dashboard.php" class="back-btn" style="display:block; margin-bottom:20px;">&larr; Back to Dashboard</a>

<!-- Categories Table -->
<table>
    <tr>
        <th>ID</th>
        <th>Category Name</th>
        <th>Actions</th>
    </tr>
    <?php while($category = mysqli_fetch_assoc($categories)): ?>
    <tr>
        <td><?php echo $category['id']; ?></td>
        <td><?php echo htmlspecialchars($category['name']); ?></td>
        <td>
            <a class="action-btn edit-btn" href="?edit=<?php echo $category['id']; ?>">Edit</a>
            <a class="action-btn delete-btn" href="?delete=<?php echo $category['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

</div>

<footer>
&copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

<?php
session_start();
include '../config/config.php';

/* Only admin access */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

/* Fetch all feedbacks */
$feedbacks_result = mysqli_query($conn, "
    SELECT f.id, f.feedback, f.created_at, 
           u.full_name AS student_name, 
           e.title AS event_title, e.event_date, e.event_time
    FROM feedbacks f
    JOIN users u ON f.student_id = u.id
    JOIN events e ON f.event_id = e.id
    ORDER BY f.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Feedbacks - Admin - VUCEMS</title>

<style>
/* ===========================
   1. RESET & BASE
=========================== */
html, body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background: #f8f9fa;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    flex: 1;
    max-width: 1000px;
    margin: 40px auto;
}

/* ===========================
   3. TABLE
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

table th,
table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    font-size: 14px;
}

table th {
    background: #004080;
    color: #fff;
}

table tr:hover {
    background: #f1f1f1;
}

/* ===========================
   4. BACK BUTTON
=========================== */
.back-btn {
    display: inline-block;
    padding: 12px 20px;
    background: #004080;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
    margin: 20px 0;
}

.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    background: #e9ecef;
    color: #666;
    margin-top: auto;
}

/* ===========================
   6. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    table {
        font-size: 12px;
    }
}

</style>
</head>
<body>

<div class="container">
    <h1 style="text-align:center;">All Student Feedbacks</h1>

    <!-- Back Button -->
    <a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

    <table>
        <tr>
            <th>#</th>
            <th>Student Name</th>
            <th>Event Title</th>
            <th>Event Date</th>
            <th>Event Time</th>
            <th>Feedback</th>
            <th>Submitted On</th>
        </tr>
        <?php if(mysqli_num_rows($feedbacks_result) > 0): 
            $count = 1;
            while($row = mysqli_fetch_assoc($feedbacks_result)): ?>
        <tr>
            <td><?= $count++ ?></td>
            <td><?= htmlspecialchars($row['student_name']) ?></td>
            <td><?= htmlspecialchars($row['event_title']) ?></td>
            <td><?= $row['event_date'] ?></td>
            <td><?= $row['event_time'] ?></td>
            <td><?= htmlspecialchars($row['feedback']) ?></td>
            <td><?= $row['created_at'] ?></td>
        </tr>
        <?php endwhile; else: ?>
        <tr>
            <td colspan="7" style="text-align:center;">No feedback submitted yet.</td>
        </tr>
        <?php endif; ?>
    </table>
</div>

<footer>
&copy; <?= date("Y") ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

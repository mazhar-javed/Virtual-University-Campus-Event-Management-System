<?php
session_start();
include '../config/config.php';

/* Only admin access */
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

$message = "";

/* Fetch categories */
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");

/* ===== Add Event ===== */
if (isset($_POST['add_event'])) {
    $title       = mysqli_real_escape_string($conn, $_POST['title']);
    $category_id = intval($_POST['category_id']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date        = $_POST['date'];
    $time        = $_POST['time'];
    $location    = mysqli_real_escape_string($conn, $_POST['location']);
    $capacity    = intval($_POST['capacity']);

    mysqli_query($conn, "
        INSERT INTO events 
        (title, category_id, description, event_date, event_time, location, capacity) 
        VALUES 
        ('$title','$category_id','$description','$date','$time','$location','$capacity')
    ");

    $message = "Event added successfully!";
}

/* ===== Delete Event ===== */
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM events WHERE id='$id'");
    $message = "Event deleted successfully!";
}

/* ===== Edit Event ===== */
if (isset($_POST['edit_event'])) {
    $id          = intval($_POST['id']);
    $title       = mysqli_real_escape_string($conn, $_POST['title']);
    $category_id = intval($_POST['category_id']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date        = $_POST['date'];
    $time        = $_POST['time'];
    $location    = mysqli_real_escape_string($conn, $_POST['location']);
    $capacity    = intval($_POST['capacity']);

    mysqli_query($conn, "
        UPDATE events SET 
            title='$title',
            category_id='$category_id',
            description='$description',
            event_date='$date',
            event_time='$time',
            location='$location',
            capacity='$capacity'
        WHERE id='$id'
    ");

    $message = "Event updated successfully!";
}

/* Fetch all events with category */
$events = mysqli_query($conn, "
    SELECT e.*, c.name AS category_name 
    FROM events e 
    LEFT JOIN categories c ON e.category_id = c.id
    ORDER BY e.event_date ASC, e.event_time ASC
");

/* Edit Mode */
$edit_event = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $edit_event = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM events WHERE id='$id'"));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Events - Admin - VUCEMS</title>
<style>
/* ===========================
   1. BASE & RESET
=========================== */
body {
    font-family: Arial, sans-serif;
    background: #f8f9fa;
    padding: 30px;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    max-width: 1000px;
    margin: auto;
}

h1 {
    color: #004080;
    margin-bottom: 10px;
}

/* ===========================
   3. TOP ACTIONS
=========================== */
.top-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

/* Back button */
.back-btn {
    background: #6c757d;
    color: #fff;
    padding: 10px 15px;
    border-radius: 5px;
    text-decoration: none;
}

.back-btn:hover {
    background: #5a6268;
}

/* ===========================
   4. FORMS & INPUTS
=========================== */
form,
table {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

label {
    font-weight: bold;
}

input,
select,
textarea {
    padding: 10px;
    width: 100%;
    margin-bottom: 10px;
}

button {
    background: #004080;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

/* ===========================
   5. TABLES
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th,
td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

th {
    background: #004080;
    color: #fff;
}

/* Table action buttons */
.btn {
    padding: 6px 10px;
    color: #fff;
    border-radius: 4px;
    text-decoration: none;
    font-size: 13px;
}

.edit {
    background: #28a745;
}

.delete {
    background: #dc3545;
}

/* ===========================
   6. FOOTER
=========================== */
footer {
    text-align: center;
    margin-top: 30px;
    color: #666;
}

</style>
</head>

<body>

<div class="container">

<div class="top-actions">
    <h1>Manage Events</h1>
    <a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>
</div>

<?php if($message): ?>
<p style="color:green"><b><?= $message ?></b></p>
<?php endif; ?>

<!-- Add / Edit Event -->
<form method="post">
<input type="hidden" name="id" value="<?= $edit_event['id'] ?? '' ?>">

<label>Event Title</label>
<input type="text" name="title" required value="<?= $edit_event['title'] ?? '' ?>">

<label>Category</label>
<select name="category_id" required>
    <option value="">-- Select Category --</option>
    <?php
    mysqli_data_seek($categories, 0);
    while ($cat = mysqli_fetch_assoc($categories)):
    ?>
    <option value="<?= $cat['id'] ?>"
        <?= ($edit_event && $edit_event['category_id']==$cat['id'])?'selected':'' ?>>
        <?= htmlspecialchars($cat['name']) ?>
    </option>
    <?php endwhile; ?>
</select>

<label>Description</label>
<textarea name="description" required><?= $edit_event['description'] ?? '' ?></textarea>

<label>Date</label>
<input type="date" name="date" required value="<?= $edit_event['event_date'] ?? '' ?>">

<label>Time</label>
<input type="time" name="time" required value="<?= $edit_event['event_time'] ?? '' ?>">

<label>Location</label>
<input type="text" name="location" required value="<?= $edit_event['location'] ?? '' ?>">

<label>Capacity</label>
<input type="number" name="capacity" required value="<?= $edit_event['capacity'] ?? '' ?>">

<button type="submit" name="<?= $edit_event ? 'edit_event' : 'add_event' ?>">
<?= $edit_event ? 'Update Event' : 'Add Event' ?>
</button>
</form>

<!-- Events Table -->
<table>
<tr>
<th>ID</th>
<th>Title</th>
<th>Category</th>
<th>Date</th>
<th>Time</th>
<th>Location</th>
<th>Capacity</th>
<th>Actions</th>
</tr>

<?php while($e = mysqli_fetch_assoc($events)): ?>
<tr>
<td><?= $e['id'] ?></td>
<td><?= htmlspecialchars($e['title']) ?></td>
<td><?= htmlspecialchars($e['category_name']) ?></td>
<td><?= $e['event_date'] ?></td>
<td><?= $e['event_time'] ?></td>
<td><?= htmlspecialchars($e['location']) ?></td>
<td><?= $e['capacity'] ?></td>
<td>
<a class="btn edit" href="?edit=<?= $e['id'] ?>">Edit</a>
<a class="btn delete" href="?delete=<?= $e['id'] ?>" onclick="return confirm('Delete event?')">Delete</a>
</td>
</tr>
<?php endwhile; ?>
</table>

</div>

<footer>
&copy; <?= date("Y") ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

<?php
session_start();
include '../config/config.php';

// Only allow admin access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: ../login.php");
    exit;
}

// Fetch some stats (optional)
$total_students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='student'"))['total'];
$total_organizers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='organizer'"))['total'];
$total_events = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM events"))['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - VUCEMS</title>
    <style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    display: flex;
    min-height: 100vh;
    background-color: #f8f9fa;
}

/* ===========================
   2. SIDEBAR
=========================== */
.sidebar {
    width: 220px;
    background-color: #004080;
    color: #fff;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 20px;
    font-size: 20px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.3);
    padding-bottom: 10px;
}

.sidebar a {
    color: #fff;
    padding: 12px 20px;
    text-decoration: none;
    display: block;
    transition: background 0.2s;
}

.sidebar a:hover {
    background-color: #0066cc;
}

/* ===========================
   3. MAIN CONTENT
=========================== */
.main-content {
    flex: 1;
    padding: 30px 40px;
}

.main-content h1 {
    color: #004080;
    margin-bottom: 25px;
}

.main-content p {
    margin-bottom: 15px;
    font-size: 16px;
}

/* ===========================
   4. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    color: #666;
    margin-top: 40px;
}

/* ===========================
   5. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    body {
        flex-direction: column;
    }

    .sidebar {
        width: 100%;
        flex-direction: row;
        overflow-x: auto;
    }

    .sidebar a {
        flex: 1;
        text-align: center;
    }

    .main-content {
        padding: 20px;
    }
}

    </style>
</head>
<body>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="manage_users.php">Manage Users</a>
    <a href="manage_events.php">Manage Events</a>
    <a href="manage_categories.php">Manage Categories</a>
    <a href="analytics.php">System Analytics</a>
    <a href="view_feedback.php">View Feedback</a>
    <a href="../logout.php">Logout</a>
</div>

<div class="main-content">
    <h1>Welcome, <?php echo $_SESSION['full_name']; ?>!</h1>

    <p><strong>Total Students:</strong> <?php echo $total_students; ?></p>
    <p><strong>Total Organizers:</strong> <?php echo $total_organizers; ?></p>
    <p><strong>Total Events:</strong> <?php echo $total_events; ?></p>

    <p>Use the sidebar to navigate and manage the system.</p>
</div>

</body>
</html>

<?php
// Include database connection
include 'config/config.php';

// Get event ID from URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../index.php");
    exit;
}

$event_id = intval($_GET['id']);

// Fetch event details
$query = "
    SELECT e.*, c.name AS category_name
    FROM events e
    LEFT JOIN categories c ON e.category_id = c.id
    WHERE e.id = '$event_id'
";
$result = mysqli_query($conn, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Event not found.");
}

$event = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($event['title']); ?> - Event Details</title>
<style>
/* ===========================
   1. BASE & RESET
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f8f9fa;
    color: #333;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* ===========================
   2. HEADER
=========================== */
header {
    background: #004080;
    color: #fff;
    padding: 20px;
    text-align: center;
}

header h1 {
    font-size: 28px;
}

/* ===========================
   3. MAIN CONTENT
=========================== */
main {
    flex: 1;
    max-width: 900px;
    margin: 30px auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

h2 {
    color: #004080;
    margin-bottom: 15px;
}

p {
    margin-bottom: 10px;
    font-size: 15px;
    line-height: 1.5;
}

/* Highlight labels */
strong {
    color: #004080;
}

/* ===========================
   4. BACK BUTTON
=========================== */
.back-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 15px;
    background: #004080;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
}

.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    background: #e9ecef;
    color: #666;
    margin-top: auto;
}

/* ===========================
   6. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    main {
        padding: 15px;
        margin: 15px;
    }

    h2 {
        font-size: 20px;
    }
}

</style>
</head>
<body>

<header>
    <h1>Event Details</h1>
</header>

<main>
    <h2><?php echo htmlspecialchars($event['title']); ?></h2>
    <p><strong>Category:</strong> <?php echo htmlspecialchars($event['category_name'] ?? 'N/A'); ?></p>
    <p><strong>Date:</strong> <?php echo date("d M Y", strtotime($event['event_date'])); ?></p>
    <p><strong>Time:</strong> <?php echo htmlspecialchars($event['event_time']); ?></p>
    <p><strong>Location:</strong> <?php echo htmlspecialchars($event['location']); ?></p>
    <p><strong>Capacity:</strong> <?php echo $event['capacity']; ?></p>
    <p><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($event['description'])); ?></p>

    <a href="index.php" class="back-btn">&larr; Back to Events</a>
</main>

<footer>
    &copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

<?php
// config/config.php

// Database configuration
$servername = "localhost";   // Usually localhost
$username   = "root";        // Your DB username
$password   = "";            // Your DB password
$database   = "vucems";      // Your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: Set character set
mysqli_set_charset($conn, "utf8");
?>

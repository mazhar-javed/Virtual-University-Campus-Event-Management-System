<?php
// Include database connection
include 'config/config.php';

$message = "";

// Handle login form submission
if(isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $hashed_password = MD5($password); // match with registration

    $query = "SELECT * FROM users WHERE email='$email' AND password='$hashed_password'";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        session_start();
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];

        // Redirect based on role
        if($user['role'] == 'student') {
            header("Location: student/dashboard.php");
            exit;
        } elseif($user['role'] == 'organizer') {
            header("Location: organizer/dashboard.php");
            exit;
        } elseif($user['role'] == 'admin') {
            header("Location: admin/dashboard.php");
            exit;
        }
    } else {
        $message = "Invalid email or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - VUCEMS</title>
    <style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f8f9fa;
    color: #333;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

a {
    text-decoration: none;
    color: #004080;
}

a:hover {
    text-decoration: underline;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    background-color: #fff;
    padding: 30px 25px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #004080;
}

/* ===========================
   3. FORM
=========================== */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    font-weight: bold;
    margin-bottom: 5px;
}

input[type="email"],
input[type="password"] {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    width: 100%;
}

/* Buttons */
input[type="submit"],
.back-btn {
    padding: 12px;
    background-color: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
    text-align: center;
}

input[type="submit"]:hover,
.back-btn:hover {
    background-color: #0066cc;
}

/* Message / Alerts */
.message {
    text-align: center;
    margin-bottom: 15px;
    color: red;
    font-weight: bold;
    font-size: 14px;
}

/* ===========================
   4. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    margin-top: 20px;
    color: #666;
}

/* ===========================
   5. RESPONSIVE
=========================== */
@media (max-width: 450px) {
    .container {
        padding: 20px 15px;
    }
}

    </style>
</head>
<body>

<div class="container">
    <h2>Login</h2>

    <?php if($message != ""): ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <input type="submit" name="login" value="Login">
    </form>

    <!-- Back to Home Button -->
    <a class="back-btn" href="index.php" style="display:block; margin-top:15px;">&larr; Back to Home</a>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

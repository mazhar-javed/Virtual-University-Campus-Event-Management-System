<?php
// Include database connection
include 'config/config.php';

// Fetch categories for filter
$categories_result = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");
$categories = mysqli_fetch_all($categories_result, MYSQLI_ASSOC);

// Search & filter
$search       = $_GET['search'] ?? '';
$category_id  = $_GET['category'] ?? '';
$date_filter  = $_GET['date'] ?? '';

$where = "WHERE event_date >= CURDATE()";
if ($search) {
    $where .= " AND title LIKE '%" . mysqli_real_escape_string($conn, $search) . "%'";
}
if ($category_id) {
    $where .= " AND category_id='" . intval($category_id) . "'";
}
if ($date_filter) {
    $where .= " AND event_date='" . mysqli_real_escape_string($conn, $date_filter) . "'";
}

$query  = "SELECT e.*, c.name AS category_name FROM events e 
           LEFT JOIN categories c ON e.category_id=c.id
           $where
           ORDER BY event_date ASC, event_time ASC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Virtual University Campus Events</title>
<style>
/* ===========================
   1. RESET & BASE STYLES
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #f8f9fa;
    color: #333;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

a {
    text-decoration: none;
    color: inherit;
}

/* ===========================
   2. HEADER
=========================== */
header {
    background: #004080;
    color: #fff;
    padding: 20px 0;
    text-align: center;
}

header h1 {
    font-size: 28px;
}

/* ===========================
   3. NAVIGATION
=========================== */
nav {
    background: #0066cc;
    padding: 12px 0;
    text-align: center;
}

nav a {
    color: #fff;
    margin: 0 15px;
    font-weight: bold;
}

nav a:hover {
    text-decoration: underline;
}

/* ===========================
   4. MAIN CONTENT
=========================== */
main {
    flex: 1;
    max-width: 1200px;
    margin: 30px auto;
    padding: 0 20px;
}

h2 {
    margin-bottom: 20px;
    text-align: center;
    color: #004080;
}

/* ===========================
   5. FILTER / SEARCH
=========================== */
.filter {
    margin-bottom: 20px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
}

.filter input,
.filter select {
    padding: 8px 12px;
    font-size: 14px;
    border-radius: 5px;
    border: 1px solid #ccc;
}

.filter button {
    padding: 8px 15px;
    background: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.filter button:hover {
    background: #0066cc;
}

/* ===========================
   6. EVENTS GRID
=========================== */
.events {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

/* ===========================
   7. EVENT CARD
=========================== */
.event-card {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s;
}

.event-card:hover {
    transform: scale(1.03);
}

.event-card h3 {
    margin-bottom: 10px;
    font-size: 20px;
    color: #004080;
}

.event-card p {
    margin-bottom: 8px;
    font-size: 14px;
}

.register-btn {
    display: inline-block;
    padding: 8px 15px;
    background: #004080;
    color: #fff;
    border-radius: 5px;
    font-size: 14px;
    margin-top: 10px;
}

.register-btn:hover {
    background: #0066cc;
}

/* ===========================
   8. FOOTER
=========================== */
footer {
    background: #004080;
    color: #fff;
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    margin-top: auto;
}

/* ===========================
   9. RESPONSIVE
=========================== */
@media (max-width: 500px) {
    nav a {
        display: block;
        margin: 8px 0;
    }
}

</style>
</head>
<body>

<header>
    <h1>Virtual University Campus Events</h1>
</header>

<nav>
    <a href="index.php">Home</a>
    <a href="login.php">Login</a>
    <a href="register.php">Register</a>
</nav>

<main>
    <h2>Upcoming Events</h2>

    <!-- Search & Filter -->
    <form method="GET" class="filter">
        <input type="text" name="search" placeholder="Search by event title" value="<?= htmlspecialchars($search) ?>">
        <select name="category">
            <option value="">All Categories</option>
            <?php foreach($categories as $cat): ?>
                <option value="<?= $cat['id'] ?>" <?= ($category_id==$cat['id'])?'selected':'' ?>><?= htmlspecialchars($cat['name']) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="date" name="date" value="<?= htmlspecialchars($date_filter) ?>">
        <button type="submit">Filter</button>
    </form>

    <div class="events">
        <?php if(mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <div class="event-card">
                    <h3><?= htmlspecialchars($row['title']) ?></h3>
                    <p><strong>Category:</strong> <?= htmlspecialchars($row['category_name'] ?? 'N/A') ?></p>
                    <p><strong>Date:</strong> <?= date("d M Y", strtotime($row['event_date'])) ?></p>
                    <p><strong>Time:</strong> <?= htmlspecialchars($row['event_time']) ?></p>
                    <p><?= htmlspecialchars(substr($row['description'],0,120)) ?>...</p>
                    <a class="register-btn" href="event_details.php?id=<?= $row['id'] ?>">View Details</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align:center;">No upcoming events found.</p>
        <?php endif; ?>
    </div>
</main>

<footer>
    &copy; <?= date("Y") ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

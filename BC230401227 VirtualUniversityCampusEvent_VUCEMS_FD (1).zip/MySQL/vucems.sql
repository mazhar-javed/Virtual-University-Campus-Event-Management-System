-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2026 at 10:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vucems`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`) VALUES
(2, 'Webinar', '2026-02-09 20:10:30'),
(3, 'Workshop', '2026-02-09 20:10:30'),
(4, 'Seminar', '2026-02-09 20:10:30'),
(5, 'Sports', '2026-02-09 20:10:30'),
(6, 'Arts & Culture', '2026-02-09 20:10:30'),
(7, 'Tech Talk', '2026-02-09 20:10:30'),
(8, 'Career Guidance', '2026-02-09 20:10:30'),
(9, 'Photography', '2026-02-09 20:10:30'),
(10, 'Entrepreneurship', '2026-02-09 20:10:30'),
(11, 'Cyber Security', '2026-02-09 20:10:30');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `organizer_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `location` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `organizer_id`, `title`, `category_id`, `description`, `event_date`, `event_time`, `location`, `capacity`, `created_at`) VALUES
(2, 2, 'AI Workshop', 2, 'Introduction to Artificial Intelligence and its applications', '2026-03-01', '11:00:00', 'Online - Zoom', 50, '2026-02-09 20:08:20'),
(3, 2, 'Web Development Seminar', 3, 'Learn modern web development techniques.', '2026-03-05', '14:00:00', 'Room A-101', 40, '2026-02-09 20:08:20'),
(4, 2, 'Sports Day', 4, 'Annual sports festival with multiple events.', '2026-03-10', '09:00:00', 'University Playground', 200, '2026-02-09 20:08:20'),
(5, 2, 'Career Guidance Session', 5, 'Guidance for final year students regarding career options.', '2026-03-12', '11:00:00', 'Auditorium', 100, '2026-02-09 20:08:20'),
(6, 2, 'Data Science Webinar', 6, 'Deep dive into data science concepts.', '2026-03-15', '16:00:00', 'Online - Google Meet', 60, '2026-02-09 20:08:20'),
(7, 2, 'Cultural Festival', 2, 'Celebrate cultural diversity with music and dance.', '2026-03-18', '10:00:00', 'Main Lawn', 300, '2026-02-09 20:08:20'),
(8, 2, 'Entrepreneurship Workshop', 3, 'Learn how to start and manage a startup.', '2026-03-20', '13:00:00', 'Room B-202', 50, '2026-02-09 20:08:20'),
(9, 2, 'Cyber Security Seminar', 4, 'Understanding cybersecurity threats and defenses.', '2026-03-22', '15:00:00', 'Lab 3', 40, '2026-02-09 20:08:20'),
(10, 2, 'Photography Competition', 6, 'Campus photography competition for students.', '2026-03-25', '09:30:00', 'Campus Grounds', 100, '2026-02-09 20:08:20'),
(11, 2, 'Tech Talk: Blockchain', 5, 'Explore blockchain technology and use cases.', '2026-03-28', '14:30:00', 'Online - Zoom', 70, '2026-02-09 20:08:20');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `feedback` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `student_id`, `event_id`, `feedback`, `created_at`) VALUES
(1, 3, 2, 'Excellent', '2026-02-09 21:21:47');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`id`, `student_id`, `event_id`, `registration_date`) VALUES
(1, 3, 2, '2026-02-09 21:18:24'),
(2, 3, 3, '2026-02-09 21:33:11'),
(3, 3, 4, '2026-02-09 21:33:13'),
(4, 3, 5, '2026-02-09 21:34:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','organizer','admin') NOT NULL DEFAULT 'student',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Admin', 'admin@admin.com', '0192023a7bbd73250516f069df18b500', 'admin', '2026-02-09 19:24:03'),
(2, 'Arslan', 'arslan@gmail.com', '202cb962ac59075b964b07152d234b70', 'organizer', '2026-02-09 19:26:33'),
(3, 'Demo', 'demo@gmail.com', '202cb962ac59075b964b07152d234b70', 'student', '2026-02-09 19:27:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `event_id` (`event_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `feedbacks_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `registrations_ibfk_2` FOREIGN KEY (`event_id`) REFERENCES `events` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

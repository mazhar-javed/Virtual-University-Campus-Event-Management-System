<?php
session_start();
include '../config/config.php';

/* Only student access */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_id   = $_SESSION['user_id'];
$student_name = $_SESSION['full_name'];

/* Fetch upcoming events with category */
$events_query = "
    SELECT e.id, e.title, e.description, e.event_date, e.event_time,
           e.location, e.capacity,
           c.name AS category_name,
           (SELECT COUNT(*) FROM registrations r WHERE r.event_id = e.id) AS registered_count
    FROM events e
    LEFT JOIN categories c ON e.category_id = c.id
    WHERE e.event_date >= CURDATE()
    ORDER BY e.event_date ASC, e.event_time ASC
";

$events_result = mysqli_query($conn, $events_query);
if (!$events_result) {
    die("Query Failed: " . mysqli_error($conn));
}

/* Fetch registered events */
$registered_events = [];
$registered_result = mysqli_query($conn, "SELECT event_id FROM registrations WHERE student_id='$student_id'");
while ($row = mysqli_fetch_assoc($registered_result)) {
    $registered_events[] = $row['event_id'];
}

/* Handle registration */
$message = "";
if (isset($_GET['register'])) {
    $event_id = intval($_GET['register']);

    if (!in_array($event_id, $registered_events)) {
        mysqli_query($conn, "INSERT INTO registrations (student_id, event_id) VALUES ('$student_id', '$event_id')");
        $registered_events[] = $event_id;
        $message = "Successfully registered for the event!";
    } else {
        $message = "You are already registered for this event!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Dashboard - VUCEMS</title>

<style>
html, body {
    height: 100%;
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f8f9fa;
}

/* Layout */
body {
    display: flex;
    min-height: 100vh;
}

/* Sidebar */
.sidebar {
    width: 220px;
    background: #004080;
    color: #fff;
    position: fixed;
    height: 100%;
}
.sidebar h2 {
    text-align: center;
    padding: 20px 0;
    border-bottom: 1px solid #0066cc;
}
.sidebar a {
    display: block;
    padding: 12px 20px;
    color: #fff;
    text-decoration: none;
    border-bottom: 1px solid #0066cc;
}
.sidebar a:hover {
    background: #0066cc;
}

/* Main */
.main {
    margin-left: 220px;
    padding: 30px;
    flex: 1;
    display: flex;
    flex-direction: column;
}

/* Message */
.message {
    color: green;
    font-weight: bold;
    margin-bottom: 20px;
}

/* Events Grid */
.events-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 20px;
}

/* Event Card */
.event-card {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}
.event-card h3 {
    margin-top: 0;
}
.event-card p {
    font-size: 14px;
    margin: 5px 0;
}
.register-btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 15px;
    background: #004080;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
}
.register-btn:hover {
    background: #0066cc;
}
.registered {
    color: #28a745;
    font-weight: bold;
}

/* Footer */
footer {
    margin-top: auto;
    text-align: center;
    padding: 15px 0;
    background: #e9ecef;
    color: #666;
}

/* Responsive */
@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        display: flex;
    }
    .sidebar a {
        flex: 1;
        text-align: center;
    }
    .main {
        margin-left: 0;
    }
}
</style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>VUCEMS</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="feedback.php">Feedback</a>
    <a href="../logout.php">Logout</a>
</div>

<!-- Main Content -->
<div class="main">
    <h1>Welcome, <?= htmlspecialchars($student_name) ?>!</h1>

    <?php if ($message): ?>
        <p class="message"><?= $message ?></p>
    <?php endif; ?>

    <h2>Upcoming Events</h2>

    <?php if (mysqli_num_rows($events_result) > 0): ?>
        <div class="events-grid">
            <?php while ($event = mysqli_fetch_assoc($events_result)): ?>
                <div class="event-card">
                    <h3><?= htmlspecialchars($event['title']) ?></h3>
                    <p><strong>Category:</strong> <?= htmlspecialchars($event['category_name'] ?? 'N/A') ?></p>
                    <p><strong>Date:</strong> <?= $event['event_date'] ?> |
                       <strong>Time:</strong> <?= $event['event_time'] ?></p>
                    <p><strong>Location:</strong> <?= htmlspecialchars($event['location']) ?></p>
                    <p><strong>Capacity:</strong> <?= $event['capacity'] ?> |
                       <strong>Registered:</strong> <?= $event['registered_count'] ?></p>
                    <p><?= htmlspecialchars($event['description']) ?></p>

                    <?php if (in_array($event['id'], $registered_events)): ?>
                        <span class="registered">Already Registered</span>
                    <?php else: ?>
                        <a class="register-btn" href="?register=<?= $event['id'] ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p>No upcoming events found.</p>
    <?php endif; ?>

    <footer>
        &copy; <?= date("Y") ?> Virtual University of Pakistan | All Rights Reserved
    </footer>
</div>

</body>
</html>

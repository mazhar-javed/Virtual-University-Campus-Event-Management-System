<?php
session_start();
include '../config/config.php';

/* Only student access */
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.php");
    exit;
}

$student_id   = $_SESSION['user_id'];
$student_name = $_SESSION['full_name'];

/* Fetch all events student has registered for */
$events_result = mysqli_query($conn, "
    SELECT e.id, e.title
    FROM events e
    JOIN registrations r ON r.event_id = e.id
    WHERE r.student_id = '$student_id'
    ORDER BY e.event_date ASC, e.event_time ASC
");

/* Handle feedback submission */
$message = "";
if (isset($_POST['submit_feedback'])) {
    $event_id = intval($_POST['event_id']);
    $feedback = mysqli_real_escape_string($conn, $_POST['feedback']);

    // Check if feedback already submitted
    $check = mysqli_query($conn, "SELECT * FROM feedbacks WHERE student_id='$student_id' AND event_id='$event_id'");
    if (mysqli_num_rows($check) > 0) {
        $message = "You have already submitted feedback for this event.";
    } else {
        mysqli_query($conn, "INSERT INTO feedbacks (student_id, event_id, feedback) VALUES ('$student_id','$event_id','$feedback')");
        $message = "Feedback submitted successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Feedback - VUCEMS</title>

<style>
/* ===========================
   1. RESET & BASE
=========================== */
html, body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background: #f8f9fa;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    flex: 1;
    max-width: 600px;
    margin: 40px auto;
}

/* ===========================
   3. FORM
=========================== */
form {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
}

form label {
    font-weight: bold;
    display: block;
    margin-bottom: 5px;
}

form select,
form textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

form textarea {
    resize: vertical;
    height: 100px;
}

form input[type="submit"],
.back-btn {
    padding: 12px 20px;
    background: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    text-decoration: none;
}

form input[type="submit"]:hover,
.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   4. MESSAGE
=========================== */
.message {
    color: green;
    font-weight: bold;
    margin-bottom: 20px;
    text-align: center;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    background: #e9ecef;
    color: #666;
    margin-top: auto;
}

</style>
</head>
<body>

<div class="container">
    <h1 style="text-align:center;">Submit Feedback</h1>

    <?php if ($message): ?>
        <p class="message"><?= $message ?></p>
    <?php endif; ?>

    <?php if(mysqli_num_rows($events_result) > 0): ?>
        <form method="post" action="">
            <label for="event_id">Select Event</label>
            <select name="event_id" id="event_id" required>
                <option value="">-- Select Event --</option>
                <?php while($event = mysqli_fetch_assoc($events_result)): ?>
                    <option value="<?= $event['id'] ?>"><?= htmlspecialchars($event['title']) ?></option>
                <?php endwhile; ?>
            </select>

            <label for="feedback">Your Feedback</label>
            <textarea name="feedback" id="feedback" placeholder="Write your feedback here..." required></textarea>

            <input type="submit" name="submit_feedback" value="Submit Feedback">
        </form>
    <?php else: ?>
        <p style="text-align:center;">You have not registered for any events yet. Please register first to submit feedback.</p>
    <?php endif; ?>

    <!-- Back Button -->
    <a href="dashboard.php" class="back-btn" style="display:block; margin:20px auto; text-align:center; width:200px; text-align:center;">&larr; Back to Dashboard</a>
</div>

<footer>
    &copy; <?= date("Y") ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

<?php
// Include database connection
include 'config/config.php';

$message = "";

// Handle form submission
if(isset($_POST['register'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Validate passwords
    if($password !== $confirm_password) {
        $message = "Passwords do not match!";
    } else {
        // Check if email already exists
        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
        if(mysqli_num_rows($check) > 0) {
            $message = "Email already registered!";
        } else {
            // Insert student into database (role = student)
            $hashed_password = MD5($password); // simple hashing for demo
            $insert = mysqli_query($conn, "INSERT INTO users (full_name,email,password,role) VALUES ('$full_name','$email','$hashed_password','student')");
            if($insert) {
                $message = "Registration successful! You can now <a href='login.php'>login</a>.";
            } else {
                $message = "Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Registration - VUCEMS</title>
    <style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background-color: #f8f9fa;
    color: #333;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

a {
    text-decoration: none;
    color: #004080;
}

a:hover {
    text-decoration: underline;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    background-color: #fff;
    padding: 30px 25px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 400px;
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #004080;
}

/* ===========================
   3. FORM
=========================== */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

label {
    font-weight: bold;
    margin-bottom: 5px;
}

input[type="text"],
input[type="email"],
input[type="password"] {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
    width: 100%;
}

/* Buttons */
input[type="submit"],
.back-btn {
    padding: 12px;
    background-color: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
    text-align: center;
}

input[type="submit"]:hover,
.back-btn:hover {
    background-color: #0066cc;
}

/* Message / Alerts */
.message {
    text-align: center;
    margin-bottom: 15px;
    color: red;
    font-weight: bold;
    font-size: 14px;
}

/* ===========================
   4. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    margin-top: 20px;
    color: #666;
}

/* ===========================
   5. RESPONSIVE
=========================== */
@media (max-width: 450px) {
    .container {
        padding: 20px 15px;
    }
}

    </style>
</head>
<body>

<div class="container">
    <h2>Student Registration</h2>

    <?php if($message != ""): ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>

    <form method="post" action="">
        <label for="full_name">Full Name</label>
        <input type="text" name="full_name" id="full_name" required>

        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <label for="confirm_password">Confirm Password</label>
        <input type="password" name="confirm_password" id="confirm_password" required>

        <input type="submit" name="register" value="Register">
    </form>

    <!-- Back to Home Button -->
    <a class="back-btn" href="index.php" style="display:block; margin-top:15px;">&larr; Back to Home</a>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

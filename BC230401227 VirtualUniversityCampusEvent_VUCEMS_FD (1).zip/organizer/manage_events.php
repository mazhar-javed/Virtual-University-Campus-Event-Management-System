<?php
session_start();
include '../config/config.php';

// Only organizer access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'organizer'){
    header("Location: ../login.php");
    exit;
}

$organizer_id = $_SESSION['user_id'];
$message = "";

// Fetch categories
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");

// ===== Add Event =====
if(isset($_POST['add_event'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category_id = intval($_POST['category_id']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $capacity = intval($_POST['capacity']);

    mysqli_query($conn, "INSERT INTO events 
    (title, category_id, description, event_date, event_time, location, capacity, organizer_id)
    VALUES 
    ('$title','$category_id','$description','$date','$time','$location','$capacity','$organizer_id')");

    $message = "Event added successfully!";
}

// ===== Delete Event =====
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM events WHERE id='$id'");
    $message = "Event deleted successfully!";
}

// ===== Edit Event =====
if(isset($_POST['edit_event'])){
    $id = intval($_POST['id']);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $category_id = intval($_POST['category_id']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $date = $_POST['date'];
    $time = $_POST['time'];
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $capacity = intval($_POST['capacity']);

    mysqli_query($conn, "UPDATE events SET
    title='$title',
    category_id='$category_id',
    description='$description',
    event_date='$date',
    event_time='$time',
    location='$location',
    capacity='$capacity'
    WHERE id='$id'");

    $message = "Event updated successfully!";
}

// Fetch events with category
$events = mysqli_query($conn, "
SELECT events.*, categories.name AS category_name
FROM events
LEFT JOIN categories ON events.category_id = categories.id
ORDER BY event_date ASC, event_time ASC
");

// Edit mode
$edit_event = null;
if(isset($_GET['edit'])){
    $id = intval($_GET['edit']);
    $edit_event = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM events WHERE id='$id'"));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Events - VUCEMS</title>
<style>
/* ===========================
   1. RESET & BASE
=========================== */
body {
    font-family: Arial, sans-serif;
    background: #f8f9fa;
    margin: 0;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    max-width: 900px;
    margin: 30px auto;
}

/* ===========================
   3. FORMS
=========================== */
form,
table {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}

form {
    margin-bottom: 20px;
    display: flex;
    flex-direction: column;
    gap: 12px;
}

input,
textarea,
select {
    width: 100%;
    padding: 10px;
    margin: 4px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

textarea {
    resize: vertical;
    height: 80px;
}

/* ===========================
   4. BUTTONS
=========================== */
button,
.btn {
    padding: 12px;
    background: #004080;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}

button:hover,
.btn:hover {
    background: #0066cc;
}

/* ===========================
   5. TABLES
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th,
td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    font-size: 14px;
}

th {
    background: #004080;
    color: #fff;
}

table tr:hover {
    background: #f1f1f1;
}

/* ===========================
   6. ACTION BUTTONS / LINKS
=========================== */
.action {
    display: flex;
    gap: 10px;
    justify-content: center;
}

.action a {
    display: inline-block;
    min-width: 65px;
    padding: 6px 12px;
    font-size: 13px;
    font-weight: 600;
    text-align: center;
    color: #fff;
    border-radius: 4px;
    text-decoration: none;
    transition: all 0.2s ease;
}

.action a.edit {
    background: #28a745;
}

.action a.edit:hover {
    background: #218838;
}

.action a.delete {
    background: #dc3545;
}

.action a.delete:hover {
    background: #c82333;
}

/* ===========================
   7. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px;
    background: #e9ecef;
    margin-top: 30px;
}

/* ===========================
   8. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    table,
    form {
        font-size: 12px;
    }
}

</style>
</head>
<body>

<div class="container">
<h2>Manage Events</h2>

<?php if($message): ?>
<p style="color:red;font-weight:bold;"><?php echo $message; ?></p>
<?php endif; ?>

<form method="post">
<input type="hidden" name="id" value="<?php echo $edit_event['id'] ?? ''; ?>">

<label>Event Title</label>
<input type="text" name="title" required value="<?php echo $edit_event['title'] ?? ''; ?>">

<label>Category</label>
<select name="category_id" required>
<option value="">-- Select Category --</option>
<?php while($cat = mysqli_fetch_assoc($categories)): ?>
<option value="<?php echo $cat['id']; ?>" 
<?php if($edit_event && $edit_event['category_id']==$cat['id']) echo 'selected'; ?>>
<?php echo htmlspecialchars($cat['name']); ?>
</option>
<?php endwhile; ?>
</select>

<label>Description</label>
<textarea name="description" required><?php echo $edit_event['description'] ?? ''; ?></textarea>

<label>Date</label>
<input type="date" name="date" required value="<?php echo $edit_event['event_date'] ?? ''; ?>">

<label>Time</label>
<input type="time" name="time" required value="<?php echo $edit_event['event_time'] ?? ''; ?>">

<label>Location</label>
<input type="text" name="location" required value="<?php echo $edit_event['location'] ?? ''; ?>">

<label>Capacity</label>
<input type="number" name="capacity" required value="<?php echo $edit_event['capacity'] ?? ''; ?>">

<button type="submit" name="<?php echo $edit_event ? 'edit_event':'add_event'; ?>">
<?php echo $edit_event ? 'Update Event':'Add Event'; ?>
</button>

<?php if($edit_event): ?>
<a href="manage_events.php" class="btn">Cancel</a>
<?php endif; ?>
</form>

<a href="dashboard.php" class="btn">← Back to Dashboard</a>

<table>
<tr>
<th>ID</th>
<th>Title</th>
<th>Category</th>
<th>Date</th>
<th>Time</th>
<th>Location</th>
<th>Capacity</th>
<th>Action</th>
</tr>

<?php while($row = mysqli_fetch_assoc($events)): ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo htmlspecialchars($row['title']); ?></td>
<td><?php echo htmlspecialchars($row['category_name']); ?></td>
<td><?php echo $row['event_date']; ?></td>
<td><?php echo $row['event_time']; ?></td>
<td><?php echo htmlspecialchars($row['location']); ?></td>
<td><?php echo $row['capacity']; ?></td>
<td class="action">
<a href="?edit=<?php echo $row['id']; ?>" class="edit">Edit</a>
<a href="?delete=<?php echo $row['id']; ?>" class="delete" onclick="return confirm('Are you sure you want to delete this event?')">Delete</a>
</td>
</tr>
<?php endwhile; ?>
</table>
</div>

<footer>
&copy; <?php echo date("Y"); ?> Virtual University of Pakistan
</footer>

</body>
</html>

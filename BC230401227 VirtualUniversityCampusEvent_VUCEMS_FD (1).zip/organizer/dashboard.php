<?php
session_start();
include '../config/config.php';

// Only organizer access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'organizer'){
    header("Location: ../login.php");
    exit;
}

$organizer_id   = $_SESSION['user_id'];
$organizer_name = $_SESSION['full_name'];

// Total events created by this organizer
$total_events_result = mysqli_query($conn, "SELECT COUNT(*) AS total_events FROM events WHERE organizer_id='$organizer_id'");
$total_events = mysqli_fetch_assoc($total_events_result)['total_events'] ?? 0;

// Total registrations across all organizer's events
$total_reg_result = mysqli_query($conn, "
    SELECT COUNT(*) AS total_regs 
    FROM registrations r
    JOIN events e ON r.event_id = e.id
    WHERE e.organizer_id='$organizer_id'
");
$total_registrations = mysqli_fetch_assoc($total_reg_result)['total_regs'] ?? 0;

// Upcoming events count
$upcoming_events_result = mysqli_query($conn, "
    SELECT COUNT(*) AS upcoming_events 
    FROM events 
    WHERE organizer_id='$organizer_id' AND event_date >= CURDATE()
");
$upcoming_events = mysqli_fetch_assoc($upcoming_events_result)['upcoming_events'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Organizer Dashboard - VUCEMS</title>
<style>
/* ===========================
   1. RESET & BASE
=========================== */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

html, body {
    height: 100%;
}

/* ===========================
   2. LAYOUT
=========================== */
body {
    display: flex;
    min-height: 100vh;
    flex-direction: column;
    background: #f8f9fa;
}

.wrapper {
    display: flex;
    flex: 1;
}

/* ===========================
   3. SIDEBAR
=========================== */
.sidebar {
    width: 220px;
    background: #004080;
    color: #fff;
    padding: 20px;
    min-height: 100%;
}

.sidebar h2 {
    margin-bottom: 30px;
    font-size: 20px;
}

.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px 15px;
    margin-bottom: 10px;
    border-radius: 5px;
}

.sidebar a:hover {
    background: #0066cc;
}

/* ===========================
   4. MAIN CONTENT
=========================== */
.main-content {
    flex: 1;
    padding: 30px;
}

/* ===========================
   5. STATISTICS CARDS
=========================== */
.stats {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.card {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
}

.card h3 {
    font-size: 22px;
    color: #004080;
    margin-bottom: 10px;
}

.card p {
    font-size: 16px;
    color: #333;
}

/* ===========================
   6. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    color: #666;
    background: #e9ecef;
}

</style>
</head>
<body>

<div class="wrapper">
    <div class="sidebar">
        <h2>Organizer Panel</h2>
        <a href="dashboard.php">Dashboard</a>
        <a href="manage_events.php">Manage Events</a>
        <a href="view_registrations.php">View Registrations</a>
        <a href="view_feedback.php">View Feedback</a>
        <a href="../logout.php">Logout</a>
    </div>

    <div class="main-content">
        <h1>Welcome, <?php echo htmlspecialchars($organizer_name); ?>!</h1>
        <p>Use the sidebar to navigate through your organizer tasks.</p>

        <!-- Statistics Section -->
        <div class="stats">
            <div class="card">
                <h3><?php echo $total_events; ?></h3>
                <p>Total Events</p>
            </div>
            <div class="card">
                <h3><?php echo $total_registrations; ?></h3>
                <p>Total Registrations</p>
            </div>
            <div class="card">
                <h3><?php echo $upcoming_events; ?></h3>
                <p>Upcoming Events</p>
            </div>
        </div>
    </div>
</div>

<footer>
&copy; <?php echo date("Y"); ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>

<?php
session_start();
include '../config/config.php';

// Only organizer access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'organizer'){
    header("Location: ../login.php");
    exit;  
}

$organizer_id = $_SESSION['user_id'];

// Fetch registrations with student info, event info, category, and registration_date
$query = "
SELECT 
    r.id AS reg_id, 
    u.full_name AS student_name, 
    u.email AS student_email, 
    e.title AS event_title, 
    e.event_date, 
    e.event_time,
    c.name AS category_name,
    r.registration_date
FROM registrations r
JOIN events e ON r.event_id = e.id
JOIN users u ON r.student_id = u.id
LEFT JOIN categories c ON e.category_id = c.id
WHERE e.organizer_id = '$organizer_id'
ORDER BY e.event_date ASC, e.event_time ASC, u.full_name ASC
";

$result = mysqli_query($conn, $query);

if(!$result){
    die("Query failed: " . mysqli_error($conn));
}

// Fetch all rows
$registrations = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Registrations - Organizer - VUCEMS</title>
<style>
/* ===========================
   1. RESET & BASE
=========================== */
html, body {
    height: 100%;
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

body {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    background: #f8f9fa;
}

/* ===========================
   2. CONTAINER
=========================== */
.container {
    flex: 1;
    max-width: 1200px;
    margin: 30px auto;
}

/* ===========================
   3. TABLE
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    margin-top: 20px;
}

table th,
table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    font-size: 14px;
}

table th {
    background: #004080;
    color: #fff;
}

table tr:hover {
    background: #f1f1f1;
}

/* ===========================
   4. BACK BUTTON
=========================== */
.back-btn {
    display: inline-block;
    padding: 12px 20px;
    background: #004080;
    color: #fff;
    border-radius: 5px;
    text-decoration: none;
    margin-top: 10px;
}

.back-btn:hover {
    background: #0066cc;
}

/* ===========================
   5. FOOTER
=========================== */
footer {
    text-align: center;
    padding: 15px 0;
    font-size: 14px;
    color: #666;
    background: #e9ecef;
    margin-top: auto;
}

/* ===========================
   6. RESPONSIVE
=========================== */
@media (max-width: 768px) {
    table {
        font-size: 12px;
    }
}

</style>
</head>
<body>

<div class="container">
    <h1>All Event Registrations</h1>

    <!-- Back to Dashboard -->
    <a href="dashboard.php" class="back-btn">&larr; Back to Dashboard</a>

    <table>
        <tr>
            <th>#</th>
            <th>Student Name</th>
            <th>Student Email</th>
            <th>Event Title</th>
            <th>Category</th>
            <th>Event Date</th>
            <th>Event Time</th>
            <th>Registration Date</th>
        </tr>
        <?php if(count($registrations) > 0): 
            $count = 1;
            foreach($registrations as $reg): ?>
        <tr>
            <td><?= $count++ ?></td>
            <td><?= htmlspecialchars($reg['student_name']) ?></td>
            <td><?= htmlspecialchars($reg['student_email']) ?></td>
            <td><?= htmlspecialchars($reg['event_title']) ?></td>
            <td><?= htmlspecialchars($reg['category_name'] ?? 'N/A') ?></td>
            <td><?= $reg['event_date'] ?></td>
            <td><?= $reg['event_time'] ?></td>
            <td><?= $reg['registration_date'] ?></td>
        </tr>
        <?php endforeach; else: ?>
        <tr>
            <td colspan="8" style="text-align:center;">No registrations found for your events.</td>
        </tr>
        <?php endif; ?>
    </table>
</div>

<footer>
&copy; <?= date("Y") ?> Virtual University of Pakistan | All Rights Reserved
</footer>

</body>
</html>
